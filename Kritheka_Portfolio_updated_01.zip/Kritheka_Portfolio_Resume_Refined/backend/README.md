# Portfolio contact API (Flask)

This backend accepts messages from the portfolio contact form and stores them in a database.

## What it does
- `GET /` and `GET /api/health`: health checks.
- `POST /api/contact`: validates and stores a contact message.
- Uses SQLite for local development and PostgreSQL when `DATABASE_URL` is set.

## Run locally (Windows)
1. Install Python 3.11+ from https://www.python.org/downloads/ and enable **Add Python to PATH** during installation.
2. Open this `backend` folder in a terminal.
3. Create a virtual environment:
   ```powershell
   py -m venv .venv
   .venv\Scripts\Activate.ps1
   ```
4. Install dependencies:
   ```powershell
   python -m pip install -r requirements.txt
   ```
5. Run the app:
   ```powershell
   python app.py
   ```
6. Open http://127.0.0.1:5000/api/health. You should see `{"status":"ok"}`.

SQLite database `messages.db` is created automatically in the backend instance folder. Do not upload real messages or database files to GitHub.

## Deploy on Render
1. Push this `backend` folder to a GitHub repository. The repository can contain this folder at its root for the easiest setup.
2. In Render, choose **New + → Blueprint** and select that repository. Render reads `render.yaml` and creates a web service plus PostgreSQL database. Review any costs/free-tier limits before confirming.
3. After deployment, open the service URL, e.g. `https://your-service-name.onrender.com/api/health`. It should return `{"status":"ok"}`.
4. Copy the service's base URL. In the portfolio's `script.js`, replace `https://YOUR-FLASK-BACKEND.onrender.com` with your actual Render URL, then commit the updated `script.js` to the portfolio repository.
5. If you change the frontend domain, update `ALLOWED_ORIGINS` in Render to the exact origin (scheme + host only, no path), separated by commas if needed.

## Security notes
- Never put database credentials or other secrets in frontend JavaScript or GitHub.
- This starter validates fields but does not yet include rate limiting, CAPTCHA, admin login, or message notification. Add abuse protection before relying on it for public production use.
- Do not create a public API endpoint for listing messages; messages contain personal data.
