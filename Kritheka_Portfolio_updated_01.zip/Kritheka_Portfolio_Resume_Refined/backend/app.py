import os
import re
from datetime import datetime, timezone

from flask import Flask, jsonify, request
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)

# Local development uses SQLite. Set DATABASE_URL in production to use PostgreSQL.
database_url = os.environ.get("DATABASE_URL", "sqlite:///messages.db")
if database_url.startswith("postgres://"):
    database_url = database_url.replace("postgres://", "postgresql+psycopg://", 1)
elif database_url.startswith("postgresql://"):
    database_url = database_url.replace("postgresql://", "postgresql+psycopg://", 1)

app.config["SQLALCHEMY_DATABASE_URI"] = database_url
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["MAX_CONTENT_LENGTH"] = 16 * 1024  # Reject unusually large requests.

db = SQLAlchemy(app)

# CORS lets the GitHub Pages frontend call this separate backend.
allowed_origins = os.environ.get(
    "ALLOWED_ORIGINS",
    "https://krithekav2005-ship-it.github.io,http://localhost:5500,http://127.0.0.1:5500"
).split(",")
CORS(app, resources={r"/api/*": {"origins": [origin.strip() for origin in allowed_origins]}})


class ContactMessage(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), nullable=False)
    email = db.Column(db.String(254), nullable=False)
    message = db.Column(db.String(3000), nullable=False)
    created_at = db.Column(db.DateTime, nullable=False, default=lambda: datetime.now(timezone.utc))


def clean_text(value):
    return value.strip() if isinstance(value, str) else ""


@app.get("/")
def home():
    return jsonify({"status": "ok", "message": "Kritheka portfolio API is running."})


@app.get("/api/health")
def health():
    return jsonify({"status": "ok"})


@app.post("/api/contact")
def create_contact_message():
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return jsonify({"error": "Please send a valid JSON request."}), 400

    name = clean_text(data.get("name"))
    email = clean_text(data.get("email"))
    message = clean_text(data.get("message"))

    if not name or not email or not message:
        return jsonify({"error": "Please complete all fields."}), 400
    if len(name) > 80:
        return jsonify({"error": "Name must be 80 characters or fewer."}), 400
    if len(email) > 254 or not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", email):
        return jsonify({"error": "Please enter a valid email address."}), 400
    if len(message) > 3000:
        return jsonify({"error": "Message must be 3000 characters or fewer."}), 400

    record = ContactMessage(name=name, email=email, message=message)
    db.session.add(record)
    db.session.commit()
    return jsonify({"message": "Thanks! Your message was sent successfully."}), 201


with app.app_context():
    db.create_all()


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "5000")), debug=True)
